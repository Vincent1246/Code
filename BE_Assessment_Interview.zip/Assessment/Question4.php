<?php

$item_tier_rarity = [1,2,3,4,5,6,7,8] ;
$vip_rank = ["vip1","vip2","vip3","vip4","vip5"];

// probability of each item for each vip rank
function roll_item($vip_rank){
    global $item_tier_rarity;
    $Allarray = [];
    foreach ($vip_rank as $indicator=> $vip){
        $array = [];
        foreach ($item_tier_rarity as $index => $value){
            if ($index <= $indicator+1){
                // higher probability (70%-100%)
                $array[$value] = rand(70,100);
            }
            else{
                // lower probability (0%-30%)
                $array[$value] = rand(0,30);
            }
        }
        // divide probabily of each rank by the sum of all probabilies * 100 
        $sumOfArray = array_sum($array);
        foreach ($array as &$p){
            $p = round($p/$sumOfArray * 100);
        }
        unset($p);
        $Allarray[$vip] =  $array;
    }
        
    return $Allarray;
}

// function to loop 100 times
function loop($vip_rank){
    for ($i = 0; $i < 100; $i++) {
        $ans = roll_item($vip_rank);
        echo "Iteration " . $i+1 . "<br>";
        printAll($ans);
    }
}

// function to print the output
function printAll($ans){
foreach ($ans as $vip => $prob) {
    echo "$vip =>" . "<br>";
    foreach ($prob as $index => $value) {
        echo "[$index] => $value" . "<br>";
    }
    echo "<br>";
}
}

//output
loop($vip_rank);


?>