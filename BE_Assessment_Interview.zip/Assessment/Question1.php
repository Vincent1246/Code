<?php

$lastDownloadTime = null;
$lastDownloadTimeArray = [];
$downloadAmount = 0;

// check user memberType
function checkDownload($memberType){
    if ($memberType === "member") {
        return handleMemberDownload();
    } elseif ($memberType === "nonmember") {
        return handleNonMemberDownload();
    } else {
        return "Invalid member type.";
    }
}

// download function for members
function handleMemberDownload() {
    global $downloadAmount;
    global $lastDownloadTimeArray;
    $currentTime = time();
    // check if download less than 2
    if ($downloadAmount < 2){
        $lastDownloadTimeArray[] = $currentTime;
        $downloadAmount ++;
        return "Your download is starting...";
        } 
    else {
        // check if downloaded image within past 5 seconds
        if ($currentTime-min($lastDownloadTimeArray) >= 5){
            $lastDownloadTimeArray[] = $currentTime;
            // drop first element (earliest time)
            array_shift($lastDownloadTimeArray);
            return "Your download is starting...";
        }
        else{
            return "Too many downloads";
        }

        }
    }

// download function for non-members
function handleNonMemberDownload() {
    global $lastDownloadTime;
    $currentTime = time();
        if (($currentTime - $lastDownloadTime) < 5) {
            return "Too many downloads";
        } else {
           $lastDownloadTime = $currentTime;
            return "Your download is starting...";
        }
    }

// output

echo "Non-member <br>";
for ($i = 0; $i < 12; $i++) {
    echo "00:00:0".$i." execute ".checkDownload("nonmember")."<br>";
    sleep(1);
}

echo "<br>";
echo "Member <br>";
for ($i = 0; $i < 12; $i++) {
    echo "00:00:0".$i." execute ".checkDownload("member")."<br>";
    sleep(1);
}
?>
