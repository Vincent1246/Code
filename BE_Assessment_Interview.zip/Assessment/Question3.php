<?php

// function to find number of days between two dates
function dayBetween($date1,$date2) {
    $dateA = date_create($date1);
    $dateB = date_create($date2);
    $diff = date_diff($dateA,$dateB);
    // extract the day between
    $diffDay = $diff->format("%a");
    return $diffDay ;

   }

// function to check odd and even
function checkOddEven($day){
    $ans = "";
    if ($day % 2 == 0){
        $ans = "even";
    }
    else{
        $ans = "odd";
    }
    return $ans ;
}

// output

$dayDiff = dayBetween("2013-11-01","2013-5-10");
    
echo "Number of days between ". $dayDiff;
echo "<br>";
echo "The day is a " . checkOddEven($dayDiff);
   
?>