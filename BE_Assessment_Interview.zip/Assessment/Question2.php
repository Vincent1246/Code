<?php

function checkDiscount($purchaseValue) {
    $currentTime = "";
    if ($purchaseValue > 500) {
        $currentTime = "10%";
    }
    else {
        if($purchaseValue < 100){
            $currentTime = "no";
        }
        else{
            $currentTime = "5%";
            }
        }
    return array($purchaseValue,$currentTime);
   }
    
// output
echo "Purchase Value is " . checkDiscount(300)[0] . " discount is " . checkDiscount(300)[1] . "<br>";
echo "Purchase Value is " . checkDiscount(80)[0] . " discount is " . checkDiscount(80)[1] . "<br>";
   
   

?>